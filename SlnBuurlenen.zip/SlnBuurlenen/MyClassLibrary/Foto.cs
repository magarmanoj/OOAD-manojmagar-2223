﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClassLibrary
{
    public class Foto
    {
        public int Id { get; set; }

        public byte[] Data { get; set; }

        public Voertuig Voertuig { get; set; }

    }
}
